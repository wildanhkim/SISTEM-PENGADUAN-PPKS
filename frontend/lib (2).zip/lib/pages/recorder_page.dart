import 'package:flutter/material.dart';

class RecorderPage extends StatelessWidget {
  const RecorderPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Halaman Recorder',
        style: TextStyle(fontSize: 24),
      ),
    );
  }
}
