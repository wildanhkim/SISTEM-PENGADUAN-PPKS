import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF000000);
  static const background = Color(0xFFFFFFFF);
}
